﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P05_Rebelion
{
    public interface INameable
    {
        string Name { get; }
    }
}
