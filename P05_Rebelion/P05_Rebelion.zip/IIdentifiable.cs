﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P05_Rebelion
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
