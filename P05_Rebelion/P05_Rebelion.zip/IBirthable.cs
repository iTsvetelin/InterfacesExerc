﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P05_Rebelion
{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}
