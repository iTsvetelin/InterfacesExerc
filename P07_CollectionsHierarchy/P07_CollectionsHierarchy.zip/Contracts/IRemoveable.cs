﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P07_CollectionsHierarchy.Contracts
{
    public interface IRemoveable
    {
        string Remove();
    }
}
