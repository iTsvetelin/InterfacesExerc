﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P07_CollectionsHierarchy.Contracts
{
    public interface IAddable
    {
        int Add(string item);
    }
}
