﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P06_MilitaryElite.Enums
{
    public enum Corps
    {
        None,
        Airforces ,
        Marines 
    }
}
